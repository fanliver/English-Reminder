					ENGLISH IDIOM REMINDER

If you get an message about installing ".Net Framework 4.0 Client Profile" before installing "Idiom Reminder", 
you can download it from this link: https://www.microsoft.com/en-us/download/details.aspx?id=24872

Your idioms will be stored in the folder: C:\Users\{UserName}\AppData\Roaming\Idioms\IdiomSource.xml
You can open that file with Internet Explorer to read its content. 
You can edit it manually to add or remove some idioms by editing its content (using Notepad, 
or Notepad++, Sublime Text, and many other editors...). 
Be careful if you want to do it, otherwise, you will get some unexpected errors when you run Idiom Reminder.

Thank you for using Idiom Reminder.

=========== Fanliver =============
| Email : pvh.fanliver@gmail.com |
| Skype : pvh.fanliver           |
==================================

